function eCircle(x, y, team) { 
    var self = this;
    self.team = team; 
    self.x1 = x;
    self.y1 = y;
    self.r = 15;
    //var x2 = 
    //var y2 = 




    self.display = function () {
        fill(255,0,0);
        ellipse(self.x1, self.y1, self.r, self.r);
    }
}
