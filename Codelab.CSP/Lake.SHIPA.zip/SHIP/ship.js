function dTriangle(x1, y1, x2, y2, x3, y3, team) {
    
    //explicit reference to self
    var self = this;


    //public on the "class"
    self.x1 = x1;
    self.y1 = y1;
    self.x2 = x2;
    self.y2 = y2;
    self.x3 = x3;
    self.y3 = y3;
    self.r = 50;
    var canFire = true;
    var delay = 220;

    self.isColliding = function(otherSprite){
        var d = dist(self.x1,self.y1, otherSprite.x, otherSprite.y);
        return d < self.r + otherSprite.r ? true : false;
    }
    
    self.handleCollision = function() {
        console.log('collision');
    }
    
    
    function fire() {
        sprites.push(new bCircle(self.x1, self.y1));
        sprites.push(new bCircle(self.x2, self.y2));
        sprites.push(new bCircle(self.x3, self.y3));
        canFire = false;
        setTimeout(cooldown, delay);
    }

    function cooldown() {
        canFire = true;
    }

    var keyboard = function () {
        var SPACE_BAR = 32;
        var speed = 4;

        if (keyIsDown(LEFT_ARROW)) {
            self.x1 -= speed;
            self.x2 -= speed;
            self.x3 -= speed;
        }

        if (keyIsDown(RIGHT_ARROW)) {
            self.x1 += speed;
            self.x2 += speed;
            self.x3 += speed;
        }

        if (keyIsDown(UP_ARROW)) {
            self.y1 -= speed;
            self.y2 -= speed;
            self.y3 -= speed;
        }

        if (keyIsDown(DOWN_ARROW)) {
            self.y1 += speed;
            self.y2 += speed;
            self.y3 += speed;
        }
        if (keyIsDown(SPACE_BAR)) {
            if (canFire)
                fire();
        }
    }
    self.display = function () {
        keyboard();
        fill(bg);
        noStroke();
        ellipse((self.x2 + self.x1) / 2, self.y3 - (self.y3 - self.y2)/ 2, self.r, self.r);
        fill(0,0,255);
        triangle(self.x1, self.y1, self.x2, self.y2, self.x3, self.y3);
        
    }
}
