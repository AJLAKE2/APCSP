var bg;
var c1;
var sprites = [];
var c2;
var self = this;

function setup() {
    createCanvas(800, 600);
    bg = color(200);
    c1 = new dTriangle(400, 580, 440, 580, 420, 535, 1);
    c2 = new eCircle(50,50,15,15, 2);
    sprites.push(c1);
    sprites.push(c2);



}

function draw() {
    background(bg);
    
    for(var i = 0; i < sprites.length; i++) {
        sprites[i].display();
    }
        
        /*for(var j = 0; j < bCircle.length; j++){
            if(sprites[i] && sprites[j]){
                checkCollision(sprites[i], sprites[j]);
            }
        }
        
    }*/
}



    
    

    //private stuff

    
    
        // we need to drag when mouse is down


    

