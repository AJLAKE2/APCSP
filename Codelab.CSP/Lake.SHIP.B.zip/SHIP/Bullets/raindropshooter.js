function RainDropShooter(x, y, team){

    Sprite.call(this, x, y, team);
    this.speed = 5;
    var canFire = true;
    
}

RainDropShooter.prototype = Object.create(Sprite.prototype);  
RainDropShooter.prototype.constructor = RainDropShooter;
RainDropShooter.prototype.r = 50;

RainDropShooter.prototype.aim = function(){
    var target = _sprites.getPlayer();
    var dx = target.x - this.x;
    var dy = target.y - this.y;
    var vector = createVector(dx,dy);
    vector.normalize();
}


RainDropShooter.prototype.fire = function(){
    var self = this;
    self.canFire = false;
    var vector = self.aim();
    if(self.canFire){
        self.canFire = false; 
        _sprites.push(new Bullet(this.x, this.y, this.team, vector.mult(7)));
        setTimeout(function(){
            self.canFire = true;
            }, 1000);
    }
    
}

RainDropShooter.prototype.control = function() {
    this.move();
    this.display();
    this.aim();
    this.fire();
}