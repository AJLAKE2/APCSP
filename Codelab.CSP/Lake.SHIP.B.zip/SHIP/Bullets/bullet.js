function Bullet(x, y, team) {

    Sprite.call(this, x, y, team); 

    
}

Bullet.prototype = Object.create(Sprite.prototype);  
Bullet.prototype.constructor = Bullet;
Bullet.prototype.r = 10;

Bullet.prototype.move = function(){
    this.y -= 10;
    }
    
Bullet.prototype.display = function(){
    fill(255,0,0);
    ellipse(this.x, this.y, this.r, this.r);
}
    

