var bg;
//var c2 = new enemy(50,50,15,15, 2);

var _sprites = [];
var _player;
var rain1;
var _enemycount = 0;


function setup() {
    createCanvas(800, 600);
    bg = color(0);
    _player = new Ship(400, 580, 440, 580, 420, 535, 1);
    _sprites.push(_player);
    //_sprites.push(c2);
    
    RespawnEnemies();

}

function draw() {
    background(bg);
    for(var i = 0; i < _sprites.length; i++) {
        _sprites[i].control();
        for(var j = 0; j < _sprites.length; j++){
            if(_sprites[i] && _sprites[j]){
                checkCollisions(_sprites[i], _sprites[j]);
            }
        }
    }


}

function checkCollisions(a,b){
    if(a.isColliding(b) && a.team !== b.team){
        a.handleCollision();
        b.handleCollision();
        
    }
} 

function RespawnEnemies(){
    _enemycount = 0;
    _sprites.push(new RainDropEnemy(100, -950, 2));
    _sprites.push(new RainDropEnemy(200, -100, 2));
    _sprites.push(new RainDropEnemy(300, 0, 2));
    _sprites.push(new RainDropEnemy(70, 0, 2));
    _sprites.push(new RainDropEnemy(500, -355, 2));
    _sprites.push(new RainDropEnemy(600, -425, 2));
    _sprites.push(new RainDropEnemy(700, -25, 2));
    _sprites.push(new RainDropEnemy(150, -1050, 2));
    //_sprites.push(new RainDropEnemy(250, -330, 2));
    /*_sprites.push(new RainDropEnemy(350, -70, 2));
    _sprites.push(new RainDropEnemy(450, 0, 2));
    _sprites.push(new RainDropEnemy(550, -550, 2));
    _sprites.push(new RainDropEnemy(650, -390, 2));
    _sprites.push(new RainDropEnemy(750, -640, 2));
    _sprites.push(new RainDropEnemy(50, -950, 2));
    */
    _sprites.push(new RainDropShooter(50, -345, 2));
    _sprites.push(new RainDropShooter(400, -255, 2));
    _sprites.push(new RainDropShooter(700, -170, 2));
    _sprites.push(new RainDropShooter(250, -470, 2));
    
    
    _sprites.push(new BabyShooter(100, 0, 2));
    _sprites.push(new BabyShooter(500, 0, 2));
    _sprites.push(new BabyShooter(300, -200, 2));

}
    

    //private stuff

    
    
        // we need to drag when mouse is down


    

