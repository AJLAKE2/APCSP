function bCircle(x, y, team ) {

    var self = this;

    self.x1 = x;
    self.y1 = y;
    self.r = 10;
    //var x2 = 
    //var y2 = 

    self.isColliding = function(otherSprite){
        var d = dist(self.x1, self.y1, otherSprite.x, otherSprite.y);
        return d < self.r + otherSprite.r ? true : false;
    }
    
    self.handleCollision = function() {
        console.log('collision');
    }


    self.display = function () {
        
        ellipse(self.x1, self.y1, self.r, self.r);
        self.y1 -= 10;
    }
}
