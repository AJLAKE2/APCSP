var bg;
//var c2 = new enemy(50,50,15,15, 2);

var _sprites = [];

var rain1;


function setup() {
    createCanvas(800, 600);
    bg = color(200);
    _sprites.push(new Ship(400, 580, 440, 580, 420, 535, 1));
    //_sprites.push(c2);

    _sprites.push(new RainDropEnemy(width/2, 0, 2));
    _sprites.push(new RainDropEnemy(width/3, 0, 2));
    _sprites.push(new RainDropEnemy(width/4, 0, 2));
    _sprites.push(new RainDropEnemy(width/2.5, 0, 2));
    _sprites.push(new RainDropEnemy(width/5, 0, 2));

}

function draw() {
    background(bg);
    for(var i = 0; i < _sprites.length; i++) {
        _sprites[i].control();
        for(var j = 0; j < _sprites.length; j++){
            if(_sprites[i] && _sprites[j]){
                checkCollisions(_sprites[i], _sprites[j]);
            }
        }
    }


}

function checkCollisions(a,b){
    if(a.isColliding(b) && a.team !== b.team){
        a.handleCollision();
        b.handleCollision();
        
    }
} 

    
    

    //private stuff

    
    
        // we need to drag when mouse is down


    

